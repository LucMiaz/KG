"""
KG-Detection
=========

The kg module.

"""
import kg.measurement_signal
import kg.measurement_values
import kg.detect
import kg.algorithm
import kg.intervals
import kg.case
#import kg.widgets
import kg.mpl_widgets


