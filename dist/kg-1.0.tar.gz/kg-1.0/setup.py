#!/usr/bin/env python

from distutils.core import setup

setup(name='kg',
      version='1.0',
      description='kg detection',
      author='esr',
      packages=['kg','mySTFT'],
     )
